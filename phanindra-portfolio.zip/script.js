
window.addEventListener("load", () => {
  document.querySelector(".loader").style.display = "none";
  document.querySelector(".app").style.display = "block";
});

document.getElementById("toggleMode").addEventListener("click", () => {
  document.body.classList.toggle("dark-mode");
});
